const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

const canvasWidth = canvas.width = 800;
const canvasHeight = canvas.height = 600;

const paddleWidth = 75;
const paddleHeight = 15;
const paddleSpeed = 7;

const brickWidth = 75;
const brickHeight = 20;
const brickPadding = 10;
const brickOffsetTop = 1;
const brickOffsetLeft = 30;

let level = 1;
let bricks = [];
let ballSpeed = 5;
let ballDirectionX = -ballSpeed;
let ballDirectionY = -ballSpeed;
let lifes = 3;
let gameStarted = false;

const maxLevels = 5;

function createBricks() {
  bricks = [];
  for (let c = 0; c < 9 ;c++) {
    for (let r = 0; r < 3; r++) {
      bricks.push({
        x: (c * (brickWidth + brickPadding)) + brickOffsetLeft,
        y: (r * (brickHeight + brickPadding)) + brickOffsetTop,
        status: true
      });
    }
  }
}

createBricks();

let paddleX = (canvasWidth - paddleWidth) / 2;
let rightPressed = false;
let leftPressed = false;

let ballX = canvasWidth / 2;
let ballY = canvasHeight - 30;

function drawBricks() {
  for (let i = 0; i < bricks.length; i++) {
    let b = bricks[i];
    if (b.status == true) {
      ctx.fillStyle = "#9B9898";
      ctx.fillRect(b.x, b.y, brickWidth, brickHeight);
      ctx.strokeStyle = "black";
      ctx.strokeRect(b.x, b.y, brickWidth, brickHeight);
    }
  }
}

function drawPaddle() {
  ctx.fillStyle = "#9B9898";
  ctx.fillRect(paddleX, canvasHeight - paddleHeight, paddleWidth, paddleHeight);
  ctx.strokeStyle = "black";
  ctx.strokeRect(paddleX, canvasHeight - paddleHeight, paddleWidth, paddleHeight);
}

function drawBall() {
  ctx.beginPath();
  ctx.arc(ballX, ballY, 10, 0, Math.PI * 2);
  ctx.fillStyle = "#9B9898";
  ctx.fill();
  ctx.closePath();
}

function drawLevel() {
  const levelDisplay = document.getElementById('level-display');
 if(level <=maxLevels)
  levelDisplay.innerHTML = "<h2 class='info'>Level: " + level+"<h2>";
  
  //levelDisplay.fillStyle = "#0095DD";
}

function drawLifes() {
  const lifesDisplay = document.getElementById('lifes-display');
  lifesDisplay.innerHTML = "<h2 class='info'>Lifes: " + lifes+"</h2>";
  //levelDisplay.fillStyle = "#0095DD";
}

function collisionDetection() {
  for (let i = 0; i < bricks.length; i++) {
    let b = bricks[i];
    if (b.status == true) {
      if (ballX > b.x && ballX < b.x + brickWidth && ballY > b.y && ballY < b.y + brickHeight) {
        ballDirectionY = -ballDirectionY;
        b.status = false;
      }
    }
  }
}

function draw() {
  ctx.clearRect(0, 0, canvasWidth, canvasHeight);
  drawBricks();
  drawPaddle();
  drawBall();
}

function update() {
  if (!gameStarted) return;

  if (rightPressed && paddleX < canvasWidth - paddleWidth) {
    paddleX += paddleSpeed;
  } else if (leftPressed && paddleX > 0) {
    paddleX -= paddleSpeed;
  }

  ballX += ballDirectionX;
  ballY += ballDirectionY;

  if (ballX + ballDirectionX > canvasWidth - 10 || ballX + ballDirectionX < 10) {
    ballDirectionX = -ballDirectionX;
  }
  if(ballY + ballDirectionY < 10){
    ballDirectionY = -ballDirectionY;
  }

  if (ballY + ballDirectionY > canvasHeight - 10 ) {
    lifes--;
    if(lifes==0){
      alert("Game Over");
      return;
    }
    ballX = paddleX;
    ballY = canvasHeight-paddleHeight-20;

    ballDirectionX = -ballSpeed;
    ballDirectionY = -ballSpeed;
  }

  if (ballX > paddleX && ballX < paddleX + paddleWidth && ballY + ballDirectionY > canvasHeight - paddleHeight - 10) {
    ballDirectionY = -ballDirectionY;
    if(ballSpeed <8)
    ballSpeed += 0.1;
  } 

  collisionDetection();

  draw();
  drawLevel();
  drawLifes();

  if (level > maxLevels) {
    return;
  }

  let allBricksDestroyed = true;
  for (let i = 0; i < bricks.length; i++) {
    if (bricks[i].status == true) {
      allBricksDestroyed = false;
      break;
    }
  }
  if (allBricksDestroyed) {
    level++;
    createBricks();
    ballX = canvasWidth / 2;
    ballY = canvasHeight - 30;
    ballDirectionX = -ballSpeed;
    ballDirectionY = -ballSpeed;
    
  }

  requestAnimationFrame(update);
}

function startGame() {
  if (!gameStarted) {
    bricks.length=0;
    level = 1;
    createBricks(level);
    ballX = canvasWidth / 2;
    ballY = canvasHeight - 30;
    ballDirectionX = -ballSpeed;
    ballDirectionY = -ballSpeed;
    lifes = 3;
    gameStarted = true;
    update();
  }
}

document.addEventListener('keydown', (e) => {
  if (e.key == 'Right' || e.key == 'ArrowRight') {
    rightPressed = true;
  } else if (e.key == 'Left' || e.key == 'ArrowLeft') {
    leftPressed = true;
  }
  if (e.key == 'Enter'){
    if (level <= maxLevels) {
      level++;
      createBricks();
      ballX = canvasWidth / 2;
      ballY = canvasHeight - 30;
      ballDirectionX = -ballSpeed;
      ballDirectionY = -ballSpeed;
    }
    if (level > maxLevels) {
      alert("Congratulazioni! Hai completato il gioco!");
      location.reload();
    }
  }
});

document.addEventListener('keyup', (e) => {
  if (e.key == 'Right' || e.key == 'ArrowRight') {
    rightPressed = false;
  } else if (e.key == 'Left' || e.key == 'ArrowLeft') {
    leftPressed = false;
  }
});